package com.example.progettolso.model;

import android.content.Intent;
import android.os.Parcel;
import android.os.Parcelable;

public class Bevanda implements Parcelable {
    private String nome;
    private String prezzo;
    private String ImageUrl;
    private int num;

    public Bevanda(String nome, String prezzo, String imageUrl,int numero) {
        this.nome = nome;
        this.prezzo = prezzo;
        this.ImageUrl = imageUrl;
        this.num=numero;
    }

    public int getNum() {
        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }

    public String getImageUrl() {
        return ImageUrl;
    }

    public void setImageUrl(String imageUrl) {
        ImageUrl = imageUrl;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getPrezzo() {
        return prezzo;
    }

    public void setPrezzo(String prezzo) {
        this.prezzo = prezzo;
    }

    //parcel part
    public Bevanda(Parcel in){
        String[] data= new String[4];

        in.readStringArray(data);
        this.nome= data[0];
        this.prezzo= data[1];
        this.ImageUrl=data[2];
        this.num=Integer.parseInt(data[3]);
    }
    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {

        dest.writeStringArray(new String[]{this.nome,this.prezzo,this.ImageUrl, Integer.toString(this.num)});
    }

    public static final Parcelable.Creator<Bevanda> CREATOR= new Parcelable.Creator<Bevanda>() {

        @Override
        public Bevanda createFromParcel(Parcel source) {
            return new Bevanda(source);
        }

        @Override
        public Bevanda[] newArray(int size) {
            return new Bevanda[size];
        }
    };
}
