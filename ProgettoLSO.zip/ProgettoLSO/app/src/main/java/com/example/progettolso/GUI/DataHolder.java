package com.example.progettolso.GUI;

import com.example.progettolso.model.Bevanda;

import java.util.ArrayList;

public class DataHolder {
    private ArrayList<Bevanda> data;
    public ArrayList<Bevanda> getData() {return data;}
    public void setData(ArrayList data) {this.data = data;}

    private static final DataHolder holder = new DataHolder();
    public static DataHolder getInstance() {return holder;}
}
