package com.example.progettolso.GUI;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import com.example.progettolso.Controller.Controller;

import com.example.progettolso.R;
import com.example.progettolso.adapter.DownloadImageTask;
import com.example.progettolso.model.Bevanda;

import java.util.ArrayList;

public class DettaglioBevanda extends AppCompatActivity {

    Controller c;
    ArrayList<String> ingredienti;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dettaglio_bevanda);
        Bevanda bevanda=getIntent().getParcelableExtra("bevanda");
        new DownloadImageTask((ImageView) findViewById(R.id.fotoDrink)).execute(bevanda.getImageUrl());
        ((TextView)findViewById(R.id.nomeDrink)).setText(bevanda.getNome());
        ListView listView=(ListView) findViewById(R.id.list_view);
        ingredienti=new ArrayList<>();
        c=new Controller();
        if(c.takeDBingredienti(bevanda,ingredienti)==true){
            ArrayAdapter<String> adapter=new ArrayAdapter<String>(this, R.layout.mytextviewsize,ingredienti);
            listView.setAdapter(adapter);
        }else{
            Toast.makeText(this,"RIPROVA",Toast.LENGTH_LONG).show();
        }
        Toolbar toolbar=findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
    }
}